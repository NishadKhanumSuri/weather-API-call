var DOM_Elements = {
    location: document.querySelector("#location"),
    selectCity: document.querySelector("#selectCountry"),
    WeatherIcon: document.querySelector("#WeatherIcon"),
    temperature: document.querySelector("#temperature"),
    humidity: document.querySelector("#humidity"),
    weather_desc: document.querySelector("#Weather_desc"),
    cloudcover: document.querySelector("#cloudcover")
}

function getWheaterData() {
    var xhttp = new XMLHttpRequest(),
        API_url = "http://api.weatherstack.com/current?access_key=ecfac891657465e96246a7430d5a492a&query=" + DOM_Elements.selectCity.value,
        weather_condition;

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            weather_condition = JSON.parse(this.responseText);
            weather_condition && setTemperature(weather_condition);
        }
    };
    xhttp.open("GET", API_url, true);
    xhttp.send();
}

function setTemperature(weather_condition) {
    DOM_Elements.location.innerHTML = "<b>Location:</b> " + " " + weather_condition.location.country + ", " + " " + weather_condition.location.name + ", " + weather_condition.location.region;
    DOM_Elements.temperature.innerHTML = "<b>Current Temperature:</b> " + weather_condition.current.temperature +"&#8451;";
    DOM_Elements.WeatherIcon.src = weather_condition.current.weather_icons[0];
    DOM_Elements.humidity.innerHTML = "<b>Humidity:</b> " + weather_condition.current.humidity;
    DOM_Elements.cloudcover.innerHTML = "<b>Cloud Cover:</b> " + weather_condition.current.cloudcover;
    DOM_Elements.weather_desc.innerHTML = "<b>Weather Description:</b> " + weather_condition.current.weather_descriptions[0];
}
